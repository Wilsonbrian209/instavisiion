let config = {
  apiKey: ""
};

export { config };
